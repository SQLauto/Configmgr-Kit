#Define the remote computer we are working against
$RemotePc = "."
# Get a list of baseline objects assigned to the remote computer
$Baselines = Get-WmiObject -ComputerName $RemotePc -Namespace root\ccm\dcm -Class SMS_DesiredConfiguration
# For each (%) baseline object, call SMS_DesiredConfiguration.TriggerEvaluation, passing in the Name and Version as params
$Baselines | % { ([wmiclass]"\\$RemotePc\root\ccm\dcm:SMS_DesiredConfiguration").TriggerEvaluation($_.Name, $_.Version) }