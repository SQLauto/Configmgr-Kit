 __    ___  __         
/ _\  / __\/ _\  /\/\  
\ \  / /   \ \  /    \ 
_\ \/ /___ _\ \/ /\/\ \
\__/\____/ \__/\/    \/

Change Product Key Tool
Version 1.0.0.0
12/11/2012

###########
README:
###########

Usage:
SCSMChangeProductKey.exe -productkey BXH69-M62YX-QQD6R-3GPWX-8WMFY [-dbUser] [-dbPassword]

Description:
This tool updates the product key used to license the Service Manager management server. It is required to run this tool on a management server machine, and as a trusted (elevated/administrator) process. Service Manager installations for which the evaluation period has expired are supported. 

IMPORTANT:
After a successful upgrade, it is required to restart the System Center Data Access service, System Center Management service and the System Center Management Configuration service to reflect the successful license upgrade. The tool will attempt to do this automatically, but in case it fails, it will have to be done manually to reflect license upgrade in the installation.

Supported versions:
The following versions of System Center Service Manager management server are supported:
No   Release	            Version
(1)  SM 2010 RTM        7.0.5826.x
(2)  SM 2010 SP1        7.0.6555.x
(3)  SM 2012 RTM        7.5.1561.x
(4)  SM 2012 SP1 Beta	7.5.2205.x
(5)  SM 2012 SP1 RC	    ??
Starting with SM 2012 SP1 Beta (7.5.2205.0), further versions of the same major version will be supported. (7.5.x.y where x > 2205)