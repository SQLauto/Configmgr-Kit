﻿
Try
{

import-module (Join-Path $(Split-Path $env:SMS_ADMIN_UI_PATH) ConfigurationManager.psd1)  
}
Catch
{
  Write-Host "[ERROR]`t SCCM Module couldn't be loaded. Script will stop!"
  Exit 1
}

$SiteCode = (Get-PSDrive -PSProvider CMSITE).name
Set-location $SiteCode":"
$SMSProvider=$sitecode.SiteServer

# Determine script location
$ScriptDir = Split-Path $script:MyInvocation.MyCommand.Path
$log      = "$ScriptDir\FallbackDP.log"
$date     = Get-Date -Format "dd-MM-yyyy hh:mm:ss"

$Server="WMYLIFEC2V6D2S.PRU.INTRANET.ASIA"

#Set-CMDistributionPoint -SiteSystemServerName $Server -AllowFallbackForContent $false

#Set-CMDistributionPoint -InputObject $Server -AllowFallbackForContent $False
<#ForEach ($DP in Import-Csv "$ScriptDir\DPcomputers.csv")

{
write-host $DP.Server

} #>

Get-CMDistributionPoint -SiteSystemServerName $Server

$DP = Get-CMDistributionPoint -SiteSystemServerName "WMYLIFEC2V6D2S.PRU.INTRANET.ASIA"

Get-CMDistributionPoint -help show-command
